#pragma once
class Weapon
{

};

