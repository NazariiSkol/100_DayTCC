#pragma once
#include "Location.h"

class GasStation : public Location
{
};

