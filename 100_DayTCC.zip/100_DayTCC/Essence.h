#pragma once
class Essence
{

};

