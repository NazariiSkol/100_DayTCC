#pragma once
#include "Location.h"

class Shop : public Location
{

};

