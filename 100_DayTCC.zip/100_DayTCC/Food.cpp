#include "Food.h"

int Food::SetSaturationUnits(int saturation_units)
{
    this->saturation_units = saturation_units;
}
