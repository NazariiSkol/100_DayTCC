#pragma once
#include "Map.h"
class ShopsMap: public Map
{
};

