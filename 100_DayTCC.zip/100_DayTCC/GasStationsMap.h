#pragma once
#include "Map.h"

class GasStationsMap : public Map
{
};

