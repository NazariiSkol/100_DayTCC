#pragma once
#include "Essence.h"
class Enemy: public Essence
{
};

