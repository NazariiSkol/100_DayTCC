#pragma once
#include "Enemy.h"
class EnemyFactory
{

};

