#pragma once
#include "Enemy.h"
class TCC : public Enemy
{

};

