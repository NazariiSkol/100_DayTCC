#pragma once
#include "Food.h"
class Stew : public Food
{
public:
 
};

