#pragma once
#include "Weapon.h"
class TraumaticGun : public Weapon
{
};

