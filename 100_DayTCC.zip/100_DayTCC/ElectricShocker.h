#pragma once
#include "Weapon.h"
class ElectricShocker : public Weapon
{
};

