#pragma once
#include "Item.h"
class Map : public Item
{

};

