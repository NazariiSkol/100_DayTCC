#pragma once
#include "Essence.h"

class Player: public Essence
{

};

