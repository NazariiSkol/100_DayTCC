#pragma once
#include "Location.h"
class FoodWarehouse : public Location
{
};

