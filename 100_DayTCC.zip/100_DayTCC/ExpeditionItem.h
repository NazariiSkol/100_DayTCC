#pragma once
#include "Item.h"
#include "Weapon.h"

class ExpeditionItem: public Item
{

};

