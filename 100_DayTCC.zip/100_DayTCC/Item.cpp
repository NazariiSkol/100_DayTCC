#include "Item.h"

void Item::SetChanceToSpawning(int chance_to_spawning)
{
	this->chance_to_spawning = chance_to_spawning;
}

void Item::SetWeight(int weight)
{
	this->weight = weight;
}
