#pragma once
class Location
{
};

