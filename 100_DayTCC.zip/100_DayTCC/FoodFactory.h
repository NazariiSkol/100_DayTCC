#pragma once
#include <memory>
class FoodFactory
{
public:
	virtual ~FoodFactory() = default;
};

