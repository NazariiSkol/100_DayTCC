#pragma once
#include "Weapon.h"
class PepperSpray : public Weapon
{
};

