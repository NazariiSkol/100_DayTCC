#pragma once
class WeaponFactory
{
};

